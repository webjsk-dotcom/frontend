# App.jsx 이벤트 핸들러 설명

이 문서는 `App.jsx`의 58-95번 줄에 있는 마우스 휠과 터치 이벤트 핸들러의 동작 원리와 역할을 설명합니다.

---

## 📋 목차

1. [개요](#개요)
2. [handleWheel - 마우스 휠 이벤트 핸들러](#handlewheel---마우스-휠-이벤트-핸들러)
3. [handleTouchStart - 터치 시작 이벤트 핸들러](#handletouchstart---터치-시작-이벤트-핸들러)
4. [handleTouchMove - 터치 이동 이벤트 핸들러](#handletouchmove---터치-이동-이벤트-핸들러)
5. [공통 패턴](#공통-패턴)
6. [전체 이벤트 흐름](#전체-이벤트-흐름)
7. [실제 사용 위치](#실제-사용-위치)
8. [비교: 마우스 휠 vs 터치](#비교-마우스-휠-vs-터치)

---

## 개요

### 코드 위치

```jsx
// src/App.jsx (58-95번 줄)
const handleWheel = useCallback(...);        // 마우스 휠 이벤트
const handleTouchStart = useCallback(...);   // 터치 시작
const handleTouchMove = useCallback(...);   // 터치 이동
```

### 역할

이 3개의 핸들러는 사용자의 입력(마우스 휠, 터치 스와이프)을 감지하여 섹션을 전환하는 기능을 제공합니다.

### 사용되는 ref

```jsx
// 32-33번 줄
const wheelLock = useRef(false);      // 스크롤 락 상태
const touchStartY = useRef(null);      // 터치 시작 위치
```

---

## handleWheel - 마우스 휠 이벤트 핸들러

### 전체 코드

```jsx
const handleWheel = useCallback(
  (event) => {
    if (wheelLock.current || isMenuOpen || showIntro) {
      return;
    }
    const delta = event.deltaY;
    if (delta === 0) return;
    wheelLock.current = true;
    changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1));
    window.setTimeout(() => {
      wheelLock.current = false;
    }, 1000);
  },
  [changeSection, isMenuOpen, showIntro]
);
```

### 단계별 동작

#### 1단계: 조건 확인 (60-62번 줄)

```jsx
if (wheelLock.current || isMenuOpen || showIntro) {
  return;
}
```

**확인하는 조건**:
- `wheelLock.current`: 다른 스크롤이 진행 중인지 확인
- `isMenuOpen`: 메뉴가 열려 있는지 확인
- `showIntro`: 인트로 애니메이션이 진행 중인지 확인

**목적**: 
- 불필요한 이벤트 처리 방지
- 섹션 전환을 차단해야 하는 상황에서 무시

**예시**:
```jsx
// 메뉴가 열려 있으면
isMenuOpen = true
→ return (이벤트 무시)

// 인트로 애니메이션 중이면
showIntro = true
→ return (이벤트 무시)

// 다른 스크롤이 진행 중이면
wheelLock.current = true
→ return (이벤트 무시)
```

#### 2단계: 스크롤 방향 확인 (63-64번 줄)

```jsx
const delta = event.deltaY;
if (delta === 0) return;
```

**`event.deltaY` 값**:
- `deltaY > 0`: 아래로 스크롤 (양수)
- `deltaY < 0`: 위로 스크롤 (음수)
- `deltaY === 0`: 스크롤 없음

**목적**: 
- 스크롤이 실제로 발생했는지 확인
- `delta === 0`이면 처리하지 않음

**예시**:
```jsx
// 사용자가 마우스 휠을 아래로 스크롤
delta = 100  // 양수
→ 다음 섹션으로 이동

// 사용자가 마우스 휠을 위로 스크롤
delta = -100  // 음수
→ 이전 섹션으로 이동

// 스크롤이 없음
delta = 0
→ return (무시)
```

#### 3단계: 락 설정 및 섹션 전환 (65-66번 줄)

```jsx
wheelLock.current = true;
changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1));
```

**동작**:
1. `wheelLock.current = true`: 추가 스크롤 차단
2. `changeSection()` 호출: 섹션 전환

**섹션 전환 로직**:
- `delta > 0` (아래로 스크롤) → `prev + 1` (다음 섹션)
- `delta < 0` (위로 스크롤) → `prev - 1` (이전 섹션)

**예시**:
```jsx
// 현재 섹션: 2
// 아래로 스크롤: delta = 100
changeSection((prev) => (100 > 0 ? prev + 1 : prev - 1))
→ prev + 1 = 2 + 1 = 3
→ Section 3으로 이동

// 현재 섹션: 2
// 위로 스크롤: delta = -100
changeSection((prev) => (-100 > 0 ? prev + 1 : prev - 1))
→ prev - 1 = 2 - 1 = 1
→ Section 1로 이동
```

#### 4단계: 1초 후 락 해제 (67-69번 줄)

```jsx
window.setTimeout(() => {
  wheelLock.current = false;
}, 1000);
```

**목적**: 
- 1초 동안 추가 스크롤 차단
- 섹션 전환 애니메이션이 완료될 때까지 대기
- 빠른 연속 스크롤로 인한 섹션 건너뛰기 방지

**타임라인**:
```
0초: wheelLock.current = true (락 설정)
     섹션 전환 시작
     ↓
1초: wheelLock.current = false (락 해제)
     다음 스크롤 가능
```

---

## handleTouchStart - 터치 시작 이벤트 핸들러

### 전체 코드

```jsx
const handleTouchStart = useCallback((event) => {
  if (isMenuOpen || showIntro) return;
  touchStartY.current = event.touches[0].clientY;
}, [isMenuOpen, showIntro]);
```

### 역할

터치가 시작될 때 손가락의 Y 좌표를 저장합니다. 이후 `handleTouchMove`에서 이동 거리를 계산하는 데 사용됩니다.

### 단계별 동작

#### 1단계: 조건 확인 (75번 줄)

```jsx
if (isMenuOpen || showIntro) return;
```

**확인하는 조건**:
- `isMenuOpen`: 메뉴가 열려 있는지
- `showIntro`: 인트로 애니메이션이 진행 중인지

**목적**: 
- 메뉴나 인트로 중에는 터치 이벤트 무시
- 섹션 전환을 차단해야 하는 상황에서 처리하지 않음

#### 2단계: 터치 시작 위치 저장 (76번 줄)

```jsx
touchStartY.current = event.touches[0].clientY;
```

**동작**:
- `event.touches[0]`: 첫 번째 터치 포인트
- `clientY`: 화면 기준 Y 좌표
- `touchStartY.current`에 저장

**예시**:
```jsx
// 사용자가 화면의 Y=500 위치를 터치
touchStartY.current = 500

// 이후 handleTouchMove에서 사용
// 이동 거리 = touchStartY.current - currentY
```

---

## handleTouchMove - 터치 이동 이벤트 핸들러

### 전체 코드

```jsx
const handleTouchMove = useCallback(
  (event) => {
    if (touchStartY.current == null || wheelLock.current || isMenuOpen || showIntro) return;
    const currentY = event.touches[0].clientY;
    const delta = touchStartY.current - currentY;
    if (Math.abs(delta) < 50) {
      return;
    }
    wheelLock.current = true;
    changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1));
    window.setTimeout(() => {
      wheelLock.current = false;
    }, 1000);
    touchStartY.current = null;
  },
  [changeSection, isMenuOpen, showIntro]
);
```

### 단계별 동작

#### 1단계: 조건 확인 (81번 줄)

```jsx
if (touchStartY.current == null || wheelLock.current || isMenuOpen || showIntro) return;
```

**확인하는 조건**:
- `touchStartY.current == null`: 터치 시작 위치가 없으면 무시
- `wheelLock.current`: 다른 스크롤이 진행 중이면 무시
- `isMenuOpen`: 메뉴가 열려 있으면 무시
- `showIntro`: 인트로 애니메이션이 진행 중이면 무시

**목적**: 
- 유효한 터치 이벤트인지 확인
- 불필요한 처리 방지

#### 2단계: 현재 터치 위치 가져오기 (82번 줄)

```jsx
const currentY = event.touches[0].clientY;
```

**동작**:
- 현재 손가락의 Y 좌표를 가져옴
- `handleTouchStart`에서 저장한 시작 위치와 비교

#### 3단계: 이동 거리 계산 (83번 줄)

```jsx
const delta = touchStartY.current - currentY;
```

**계산 공식**:
```
delta = 시작 위치 - 현재 위치
```

**결과 해석**:
- `delta > 0`: 위로 스와이프 (시작 위치가 더 아래)
- `delta < 0`: 아래로 스와이프 (시작 위치가 더 위)

**예시**:
```jsx
// 시작 위치: 500
// 현재 위치: 400 (위로 이동)
delta = 500 - 400 = 100 (양수)
→ 위로 스와이프 → 다음 섹션

// 시작 위치: 500
// 현재 위치: 600 (아래로 이동)
delta = 500 - 600 = -100 (음수)
→ 아래로 스와이프 → 이전 섹션
```

#### 4단계: 최소 이동 거리 확인 (84-86번 줄)

```jsx
if (Math.abs(delta) < 50) {
  return;
}
```

**목적**: 
- 50px 미만의 작은 움직임은 무시
- 의도치 않은 섹션 전환 방지
- 사용자가 살짝만 움직였을 때 섹션이 바뀌는 것을 방지

**예시**:
```jsx
// 30px만 움직임
Math.abs(30) = 30 < 50
→ return (무시)

// 80px 움직임
Math.abs(80) = 80 >= 50
→ 섹션 전환 진행
```

#### 5단계: 락 설정 및 섹션 전환 (87-88번 줄)

```jsx
wheelLock.current = true;
changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1));
```

**동작**:
1. `wheelLock.current = true`: 추가 스크롤 차단
2. `changeSection()` 호출: 섹션 전환

**섹션 전환 로직**:
- `delta > 0` (위로 스와이프) → `prev + 1` (다음 섹션)
- `delta < 0` (아래로 스와이프) → `prev - 1` (이전 섹션)

**예시**:
```jsx
// 현재 섹션: 2
// 위로 스와이프: delta = 100
changeSection((prev) => (100 > 0 ? prev + 1 : prev - 1))
→ prev + 1 = 2 + 1 = 3
→ Section 3으로 이동

// 현재 섹션: 2
// 아래로 스와이프: delta = -100
changeSection((prev) => (-100 > 0 ? prev + 1 : prev - 1))
→ prev - 1 = 2 - 1 = 1
→ Section 1로 이동
```

#### 6단계: 1초 후 락 해제 및 초기화 (89-92번 줄)

```jsx
window.setTimeout(() => {
  wheelLock.current = false;
}, 1000);
touchStartY.current = null;
```

**동작**:
1. 1초 후 `wheelLock.current = false`: 락 해제
2. `touchStartY.current = null`: 터치 시작 위치 초기화

**목적**: 
- 다음 터치를 위해 상태 초기화
- 1초 동안 추가 스크롤 차단

---

## 공통 패턴

### 1. wheelLock 메커니즘

#### 동작 흐름

```jsx
// 사용 전
wheelLock.current = false  // 스크롤 가능

// 사용 중
wheelLock.current = true   // 스크롤 차단

// 1초 후
wheelLock.current = false  // 다시 스크롤 가능
```

#### 목적

**빠른 연속 스크롤 방지**:
- 사용자가 빠르게 여러 번 스크롤해도 1초에 한 번만 섹션 전환
- 섹션을 건너뛰는 것을 방지
- 부드러운 사용자 경험 제공

#### 타임라인 예시

```
0.0초: 사용자가 마우스 휠을 아래로 스크롤
       wheelLock.current = true
       Section 1 → Section 2로 전환 시작

0.1초: 사용자가 또 스크롤 (무시됨)
       wheelLock.current = true이므로 return

0.5초: 사용자가 또 스크롤 (무시됨)
       wheelLock.current = true이므로 return

1.0초: wheelLock.current = false
       다음 스크롤 가능해짐
```

### 2. 조건 체크 순서

모든 핸들러에서 동일한 순서로 조건을 확인합니다:

```jsx
// 1. 락 상태 확인
if (wheelLock.current) return;

// 2. 메뉴/인트로 상태 확인
if (isMenuOpen || showIntro) return;

// 3. 이벤트 처리
// ...
```

**이유**: 
- 가장 빠르게 확인할 수 있는 조건부터 체크
- 불필요한 처리 방지

### 3. 섹션 전환 로직

두 핸들러 모두 동일한 로직을 사용합니다:

```jsx
changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1));
```

**공식**:
- `delta > 0` → 다음 섹션 (`prev + 1`)
- `delta < 0` → 이전 섹션 (`prev - 1`)

**주의**: 
- 마우스 휠: `delta > 0` = 아래로 스크롤
- 터치: `delta > 0` = 위로 스와이프
- 하지만 둘 다 다음 섹션으로 이동 (직관적인 동작)

---

## 전체 이벤트 흐름

### 마우스 휠 이벤트 흐름

```
1. 사용자가 마우스 휠을 스크롤
   ↓
2. handleWheel 실행
   ↓
3. 조건 확인
   ├─ wheelLock? → return
   ├─ isMenuOpen? → return
   └─ showIntro? → return
   ↓
4. delta 계산
   ├─ delta === 0? → return
   └─ delta !== 0? → 진행
   ↓
5. wheelLock 설정
   wheelLock.current = true
   ↓
6. 섹션 전환
   changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1))
   ↓
7. 1초 후 락 해제
   window.setTimeout(() => {
     wheelLock.current = false;
   }, 1000)
```

### 터치 이벤트 흐름

```
1. 사용자가 화면을 터치
   ↓
   handleTouchStart 실행
   ↓
   조건 확인 (isMenuOpen, showIntro)
   ↓
   touchStartY.current에 시작 위치 저장

2. 손가락을 움직임
   ↓
   handleTouchMove 실행
   ↓
   조건 확인
   ├─ touchStartY.current == null? → return
   ├─ wheelLock.current? → return
   ├─ isMenuOpen? → return
   └─ showIntro? → return
   ↓
   현재 위치 가져오기
   currentY = event.touches[0].clientY
   ↓
   이동 거리 계산
   delta = touchStartY.current - currentY
   ↓
   최소 거리 확인
   Math.abs(delta) < 50? → return
   ↓
   wheelLock 설정
   wheelLock.current = true
   ↓
   섹션 전환
   changeSection((prev) => (delta > 0 ? prev + 1 : prev - 1))
   ↓
   1초 후 락 해제 및 초기화
   window.setTimeout(() => {
     wheelLock.current = false;
   }, 1000)
   touchStartY.current = null

3. 손가락을 뗌
   ↓
   handleTouchEnd 실행
   ↓
   touchStartY.current 초기화 (이미 null)
```

---

## 실제 사용 위치

### 코드에서의 사용

```jsx
// src/App.jsx (127-133번 줄)
<div
  id="fullpage"
  onWheel={handleWheel}        // 마우스 휠 이벤트
  onTouchStart={handleTouchStart}  // 터치 시작
  onTouchMove={handleTouchMove}    // 터치 이동
  onTouchEnd={handleTouchEnd}      // 터치 종료
>
  <div className="full_cover" style={fullCoverStyle}>
    {/* 섹션들 */}
  </div>
</div>
```

### 이벤트 바인딩

- `onWheel`: 마우스 휠 스크롤 감지
- `onTouchStart`: 터치 시작 감지
- `onTouchMove`: 터치 이동 감지
- `onTouchEnd`: 터치 종료 감지

---

## 비교: 마우스 휠 vs 터치

### 비교표

| 구분 | handleWheel | handleTouchMove |
|------|-------------|-----------------|
| **이벤트 타입** | `wheel` | `touchmove` |
| **방향 감지** | `event.deltaY` | `touchStartY - currentY` |
| **최소 거리** | 없음 | 50px |
| **락 메커니즘** | 동일 (1초) | 동일 (1초) |
| **사용 환경** | 데스크톱 | 모바일/태블릿 |
| **시작 위치 저장** | 불필요 | 필요 (`touchStartY`) |

### 방향 해석 차이

#### 마우스 휠

```jsx
delta = event.deltaY
// delta > 0: 아래로 스크롤 → 다음 섹션
// delta < 0: 위로 스크롤 → 이전 섹션
```

#### 터치

```jsx
delta = touchStartY.current - currentY
// delta > 0: 위로 스와이프 → 다음 섹션
// delta < 0: 아래로 스와이프 → 이전 섹션
```

**차이점**: 
- 마우스 휠: 아래로 스크롤 = 다음 섹션
- 터치: 위로 스와이프 = 다음 섹션 (스크롤과 반대)

**이유**: 
- 터치에서 위로 스와이프는 콘텐츠를 위로 올리는 것처럼 보임
- 사용자 경험상 자연스러운 동작

---

## 보호 메커니즘

### 1. wheelLock - 연속 스크롤 방지

```jsx
wheelLock.current = true;  // 락 설정
// 1초 후
wheelLock.current = false; // 락 해제
```

**효과**: 
- 빠른 연속 스크롤 방지
- 섹션 건너뛰기 방지
- 부드러운 애니메이션 보장

### 2. isMenuOpen - 메뉴 열림 중 차단

```jsx
if (isMenuOpen) return;
```

**효과**: 
- 메뉴 열림 중에는 섹션 전환 불가
- 메뉴와 섹션 전환 충돌 방지

### 3. showIntro - 인트로 중 차단

```jsx
if (showIntro) return;
```

**효과**: 
- 인트로 애니메이션 중에는 섹션 전환 불가
- 인트로와 섹션 전환 충돌 방지

### 4. 최소 이동 거리 - 터치 시

```jsx
if (Math.abs(delta) < 50) {
  return;
}
```

**효과**: 
- 의도치 않은 작은 움직임 무시
- 섹션 전환의 정확도 향상

---

## 요약

### 핵심 기능

1. **마우스 휠 스크롤로 섹션 전환** (`handleWheel`)
2. **터치 스와이프로 섹션 전환** (`handleTouchStart`, `handleTouchMove`)
3. **1초 쿨다운으로 빠른 연속 스크롤 방지** (`wheelLock`)
4. **메뉴/인트로 중에는 섹션 전환 차단**

### 보호 메커니즘

- `wheelLock`: 연속 스크롤 방지
- `isMenuOpen`: 메뉴 열림 중 차단
- `showIntro`: 인트로 중 차단
- 최소 이동 거리: 터치 시 50px 이상만 인식

### 사용자 경험

- **데스크톱**: 마우스 휠로 섹션 전환
- **모바일/태블릿**: 터치 스와이프로 섹션 전환
- **모든 환경**: 부드럽고 안정적인 섹션 전환

---

## 관련 파일

- `src/App.jsx`: 메인 앱 컴포넌트 (이벤트 핸들러 정의)
- `src/components/Section*.jsx`: 각 섹션 컴포넌트

---

**작성일**: 2024  
**프로젝트**: 나스미디어 React 웹사이트



