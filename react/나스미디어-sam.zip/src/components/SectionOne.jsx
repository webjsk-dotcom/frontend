function SectionOne() {
  return (
    <section id="section1" className="section">
      <div className="sub-txt">
        <h3 className="sub-txt1">MORE THAN EXPECTED!</h3>
        <h1 className="sub-txt2">No.1 Digital Media Rep.</h1>
      </div>
    </section>
  );
}

export default SectionOne;



