function FloatingAd() {
  return (
    <div id="ad-fix">
      <a href="#">
        <p>광고문의</p>
        <i className="fa-solid fa-tv" aria-hidden="true" />
      </a>
    </div>
  );
}

export default FloatingAd;



